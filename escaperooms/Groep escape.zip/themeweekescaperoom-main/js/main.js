const startBTN = document.querySelector(".start-btn");

function startgame() {
  console.log("test2");
  window.location.href = "flashlightpuzzle.html";
}

startBTN.addEventListener("click", startgame);
