const startBTN = document.querySelector(".start-btn");

function startgame() {
  console.log("test2");
  window.location.href = "raadsel.html";
}

startBTN.addEventListener("click", startgame);
