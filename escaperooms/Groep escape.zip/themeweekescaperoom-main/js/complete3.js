const startBTN = document.querySelector(".start-btn");

function startgame() {
  console.log("test2");
  window.location.href = "puzzle3code.html";
}

startBTN.addEventListener("click", startgame);
