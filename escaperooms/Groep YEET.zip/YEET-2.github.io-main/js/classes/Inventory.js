export default class Inventory { //static class Inventory
    constructor() {
        if (this instanceof Inventory) {
          throw Error('A static class cannot be instantiated.');
        }
    }

    static #content = []; //private static

    static #selectedIndex;

    static getInventory() {
        return this.#content;
    }

    static addItem(name, texture) {
        this.#content.push({
            name: name,
            texture: texture
        });
    }

    static getSelectedItem() { //getSelectedItem().name, getSelectedItem().texture - if user cicks --> if(Inventory.getSelectedItem().name === "Key") { // open door }
        if(this.#selectedIndex === null) {
            return null;
        }
        return this.#content[this.#selectedIndex];
    }

    static selectItem(index) {
        if(index === this.#selectedIndex) {
            this.#selectedIndex = null;
        } else {
            this.#selectedIndex = index;
        }        
    }

    static addKey() {
        this.addItem("Key", "./img/key.png");
    }

    static removeKey() {
        let filtered = this.#content.filter(function(value){ 
            return value.name !== "Key";
        });
        this.#content = filtered;
    }

}