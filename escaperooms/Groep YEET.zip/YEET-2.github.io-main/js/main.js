//import styles to apply to canvas
import '../css/style.css'

//threej (for animations and 3d objects)
import * as THREE from 'three'
import Inventory from './classes/Inventory.js';
import updateInv from './inv'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js'
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader'
//gsap (for animations)
import { gsap } from 'gsap'
import { DoubleSide } from 'three';
import * as howler from 'howler'



//dom
const inventoryEl = document.querySelector(".inventory");
const close = document.querySelector('.close')
const codebox = document.querySelector('.container-codecrack')
const memoryGame=document.querySelector(".m-puzzle");
const panel=document.querySelector(".panel");
const symbol = document.querySelector('.symbol-game')
const backgroundAudio = document.querySelector('audio')
//threejs

//scene and camera
const scene = new THREE.Scene()
const camera = new THREE.PerspectiveCamera(75, innerWidth / innerHeight, 0.1, 50000)

//camera position
camera.position.z = 7200
camera.position.y = 4200

//renderer
const renderer = new THREE.WebGLRenderer({ antialias: true })
document.body.appendChild(renderer.domElement)

renderer.setPixelRatio(devicePixelRatio)
renderer.setSize(innerWidth, innerHeight)

//envent listeners
window.addEventListener('mousemove', onMouseMove, false);
renderer.domElement.addEventListener('click', clickObject, true)
close.addEventListener('click', () => {
    codebox.classList.add('visible')
    gsap.to(Pointlight, { intensity: 1 })
})
const audio = new Audio('/audio/background.mp3')
// window.addEventListener('load', ()=>{
//     audio.play()
// })
const sound = new howler.Howl({
    src: ['/audio/background.mp3']
})
sound.play()
sound.volume(2)
//controls
const controls = new OrbitControls(camera, renderer.domElement)
controls.enableZoom = false
controls.enablePan = false
controls.enableRotate = false
/* 
  right click and drag to move around one point
  scroll to zoom in / zoom out
  left click to move along the x and y axis
*/

//loader for 3d models
const modelLoader = new GLTFLoader()

AddObject('/models/Lock.glb', 'locked_lock1', 0, 0, 400, -4700, 0)
AddObject('/models/Desk.glb', 'Desk1', 20000, 4300, -5000, -3400, 0)
AddObject('/models/Chair.glb', 'Chair', 400000, 4400, -5000, -2000, 90)
AddObject('/models/Rug.glb', 'Rug', 20000, -1000, -5000, 1000, 0)
AddObject('/models/Dresser.glb', 'Dresser', 20000, -5700, -5000, -3400, 0)

const textureloader = new THREE.TextureLoader()
const materialArray = []
//load skybox textures
function loadTextureBox(path) {
    materialArray.push(new THREE.MeshPhongMaterial({ map: textureloader.load(path) }))
}
loadTextureBox('/textures/wall1.jpg')
loadTextureBox('/textures/wall1.jpg')
loadTextureBox('/textures/wall1.jpg')
loadTextureBox('/textures/floor1.jpg')
loadTextureBox('/textures/wall1.jpg')
loadTextureBox('/textures/wall1.jpg')

const textureloader5 = new THREE.TextureLoader().load('/textures/sint.png')
const textureloader6 = new THREE.TextureLoader().load('/textures/door.jpg')

for (let i = 0; i < materialArray.length; i++) {
    materialArray[i].side = THREE.BackSide
}

//rooms
const Pointlight = new THREE.PointLight(0xffffff, 1, 2, 0)
Pointlight.position.z = 45
const cube = new THREE.BoxGeometry(15000, 10000, 10000)
const cubemesh = new THREE.Mesh(cube, materialArray)
const cubemesh2 = new THREE.Mesh(cube, materialArray)
const cubemesh3 = new THREE.Mesh(cube, materialArray)
//painting and other objects
const painting = new THREE.PlaneGeometry(3000, 5000)
const paintingmat = new THREE.MeshStandardMaterial({ color: 0xffffff, map: textureloader5 })
const paintingmesh = new THREE.Mesh(painting, paintingmat)
paintingmesh.name = 'painting'
paintingmesh.position.set(0, 400, -4700)
//door
const doorgeo = new THREE.PlaneGeometry(3000, 5000)
const doormat = new THREE.MeshPhongMaterial({ map:textureloader6, side:DoubleSide })
const door = new THREE.Mesh(doorgeo, doormat)
scene.add(door)
door.position.set(7000, -2500, 1000)
door.rotateY(Math.PI*1.5)
console.log(door)

door.name = 'door'
//table


//groups
const rooms = new THREE.Group()
const roomObjects = new THREE.Group()
rooms.add(cubemesh, cubemesh2, cubemesh3)

//set positions for the diffrent positions
for (let i = 0; i < rooms.children.length; i++) {
    rooms.children[i].position.x = i * 20000
}
//light(ambient to light up the whole scene)
const ambient = new THREE.AmbientLight(0xffffff, .3)
//make screen responsive when resized(applies for threejs)
function makeResponsive() {
    window.addEventListener('resize', () => {
        renderer.setSize(innerWidth, innerHeight)
        camera.aspect = innerWidth / innerHeight

        camera.updateProjectionMatrix()
    })
}
const mouse = new THREE.Vector2();
const raycaster = new THREE.Raycaster();
//animate the objects must be done with gsap for simplicity
function animate() {
    requestAnimationFrame(animate)
    raycaster.setFromCamera(mouse, camera);

    renderer.render(scene, camera)
}
animate()

makeResponsive()
//add 3d model to the scene
function AddObject(path, name, scale, posX, posY, posZ, rotation) {
    modelLoader.load(path, function (gltf) {
        gltf.scene.name = name
        gltf.scene.scale.setScalar(scale)
        gltf.scene.position.set(posX, posY, posZ)
        gltf.scene.rotateY(rotation)
        roomObjects.add(gltf.scene)
    }) 
} 

//add objects to the scene
scene.add(rooms, Pointlight, paintingmesh, ambient, roomObjects)
let roomindex = 1
//switch rooms
const switchButton = document.querySelector('.switch__rooms')
switchButton.addEventListener('click', SwitchRoom)
function SwitchRoom() {
    const timeline = new gsap.timeline({ autoRemoveChildren: true, repeat: 2 })
    timeline.addLabel("fadeout", "+=1")
    timeline.addLabel("fadein", "+=4")
    timeline.addLabel("camPos", "+=2")

    gsap.to(ambient, { intensity: 0 }, 1, "fadeout")
    gsap.to(Pointlight, { intensity: 0 }, 1, "fadeout")
    gsap.to(camera.position, {x: '+=20000'}, "camPos")

    gsap.to(Pointlight, { intensity: 1 }, "fadein +=2")
    gsap.to(ambient, { intensity: 1 }, "fadein +=2")

    
    roomObjects.position.x += 20000
    paintingmesh.position.x += 20000
    door.position.x += 20000
    roomObjects.remove(roomObjects.getObjectByName('locked_lock1'))


    roomindex++
    Inventory.removeKey()
    updateInv()
}
if (roomindex == 3) {
    const secretKey = 1641518
    let lastInput= prompt('vul de keycode in')
    if (lastInput.value== secretKey.toString()) {
        window.location = 'credits.html'
    }
}



//calculates normalized position for the mouse
function onMouseMove(event) {
    // calculate mouse position in normalized device coordinates
    // (-1 to +1) for both components
    mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
    mouse.y = - (event.clientY / window.innerHeight) * 2 + 1;
}

//checks if a threejs object has been clicked
function clickObject(event) {
    const intersects = raycaster.intersectObjects(scene.children)
    intersects.forEach(element => {
        switch (element.object.name) {
            case 'painting':
                if (element.object.position.x != 0) {
                    gsap.to(element.object.position, { x: 0 })
                    roomObjects.getObjectByName('locked_lock1').scale.setScalar(0)
                }
                else {
                    gsap.to(element.object.position, { x: -3000 })
                    roomObjects.getObjectByName('locked_lock1').scale.setScalar(5000)
                }
                console.log(element.object.material.opacity)
                break;

            case 'dresser1':
                if (roomindex == 2) {
                    symbol.classList.remove('visible')
                }


                break;
            case 'desk1':
                if (roomindex == 3) {
                    memoryGame.classList.remove("visible");
                    panel.classList.remove("visible");
                }
                break;
            case 'locked_lock1':
                codebox.classList.remove('visible')
                gsap.to(Pointlight, { intensity: 0 })
                break;
            case 'door':
                if(Inventory.getSelectedItem().name === "Key"){
                    gsap.to(door.rotation, {y:-Math.PI/3})
                    SwitchRoom()
                }
                if (roomindex == 3 && Inventory.selectItem().name === "key") {
                    window.location = 'credits.html'
                }
                else{
                    alert('verkrijg eerst de sleutel')
                }
                break;
            default:
                break;
        }
    });

}
//popup
//on click of lock
//get key once right code is entered

//crack the code
const userInputs = document.querySelectorAll(".num-input");
const locker = document.querySelector(".locker");
const checkBtn = document.querySelector(".check-btn");

checkBtn.addEventListener('click', () => {
    if (userInputs[0].value == "1" && userInputs[1].value == "6" && userInputs[2].value == "4") {
        locker.src = "../img/unlocked_lock.png";
        setTimeout(function () {
            codebox.classList.add('visible')
            gsap.to(Pointlight, { intensity: 1 })
            Inventory.addKey()
            updateInv()
        }, 200);
    }
    else {
        alert("Oeps de code is niet correct \n Probeer opnieuw");
        userInputs[0].value = "";
        userInputs[1].value = "";
        userInputs[2].value = "";
    }
})

// sybol puzzle
const johntyUserInput=document.querySelector(".user-input-johnty");
const johntyCheckBtn=document.querySelector(".checken-johnty")

johntyCheckBtn.addEventListener('click',()=>{
    if(johntyUserInput.value==15){
        Inventory.addKey()
        updateInv()
        alert("Goed gedaan")
        symbol.classList.add("visible")
    }
    else{
        alert("Porbeer nog een keer")
        johntyUserInput.textContent=0;
    }
})
//memory game
const puzzleGame =document.querySelector(".memory-game");
const memoryCards = document.querySelectorAll(".back");
const pointsPanel=document.querySelector(".points-panel");
const timePanel=document.querySelector(".time-panel");
const timerStarterBtn=document.querySelector(".timer-starter");
let clickedCard;
let clickedCardValue=[];
let comparisionValue;
let flips= [];
let points=0;
for(let i=0 ;i<memoryCards.length;i++){
    memoryCards[i].addEventListener('click', function(e){
        //de numerieke value ophalen om te kunnen vergelijken
        comparisionValue=e.path[0].classList[1]
        
        clickedCard=e.target;
        clickedCard.classList.toggle("flipped-card");
        flips.push(clickedCard);
        clickedCardValue.push(comparisionValue);
        console.log(flips)
        
        flipsArrayRearrange();
        guessedCard()
    })
}

function flipsArrayRearrange(){
    if(flips.length>=2){
        setTimeout(() => { flips=[] }, 2100)
    }
    else{
        cardFaceReset();
    }
    if(clickedCardValue.length>=2){
        setTimeout(() => { clickedCardValue=[] }, 1300)
    }
}

function cardFaceReset(){
    setTimeout(() => {
        console.log(flips[0]);
        console.log(flips[1]);
        console.log(clickedCardValue[0]);
        console.log(clickedCardValue[1]);
        try{
            flips[0].classList.toggle("flipped-card");
            flips[1].classList.toggle("flipped-card");
        }
        catch{
            console.log("selecteer je volgende kaart")
        }
        }, 1000)
    
}

function guessedCard(){
    if(clickedCardValue[0]==clickedCardValue[1]){
        flips[0].classList.add("flipped-card");
        flips[1].classList.add("flipped-card");
        points++;
        setTimeout(() => { pointsPanel.textContent=points; }, 200)
    }
    else{
        cardFaceReset();
    }
}

if (points == 18) {
    Inventory.addKey()
    updateInv()
    memoryGame.classList.add('visible')
    puzzleGame.classList.add('visible')
    pointsPanel.classList.add('visible')
}



