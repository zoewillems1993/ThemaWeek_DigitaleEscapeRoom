import Inventory from './classes/Inventory.js';

const inventoryEl = document.querySelector(".inventory");

export default function updateInventoryUI() {
    inventoryEl.innerHTML = "";
    Inventory.selectItem(null);
    let newInventoryContent = Inventory.getInventory();
    newInventoryContent.forEach(function(element, index, array) {
        let inventorySlotEl = document.createElement("div");
        inventorySlotEl.classList.add("inventory_slot");
        let invImg = document.createElement("img");
        invImg.setAttribute("src", element.texture);
        invImg.setAttribute("title", element.name);
        invImg.setAttribute("width", "50px");
        invImg.setAttribute("height", "50px");
        /*let invTxt = document.createElement("span");
        invTxt.innerText = element.name;*/
        inventorySlotEl.appendChild(invImg);
        //inventorySlotEl.appendChild(invTxt);
        inventorySlotEl.addEventListener("click", function() {
            Inventory.selectItem(index);
            inventorySlotEl.classList.toggle("inventory_slot_selected");
            let allInventorySlots = Array.from(inventoryEl.children);
            allInventorySlots.forEach(function(_element, _index, _array) {
                if(_element !== inventorySlotEl && _element.classList.contains("inventory_slot_selected")) {
                    _element.classList.toggle("inventory_slot_selected");
                }
            });
        }, false);
        inventoryEl.appendChild(inventorySlotEl);
    });
}


