window.addEventListener('load',function(){
    let counter = 0;
    let seconds = "00";
    let minutes = "00";
    const getTimerMinutes = (counter) => {
    let minuteCounter = Math.floor(counter / 60);
    return minuteCounter < 10 ? `0${minuteCounter}` : `${minuteCounter}`;
    };

    const getTimerSeconds = (counter) => {
    let secondCounter = counter % 60;
    document.getElementById("second-box").innerHtml =
        secondCounter < 10 ? `0${secondCounter}` : `${secondCounter}`;
    return secondCounter < 10 ? `0${secondCounter}` : `${secondCounter}`;
    };
    const setCount = () => {
    console.log("here");
    seconds = getTimerSeconds(counter);
    minutes = getTimerMinutes(counter);

    document.getElementById("minute-box").innerHtml = seconds;
    counter = counter + 1;
    };

    var intervalId = window.setInterval(function () {
    seconds = getTimerSeconds(counter);
    minutes = getTimerMinutes(counter);
    document.getElementById("minute-box").innerHTML = minutes;
    document.getElementById("second-box").innerHTML = seconds;
    counter = counter + 1;
    }, 1000);
})