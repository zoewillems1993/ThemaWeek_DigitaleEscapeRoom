let creditsList = [["Jona", "three.js (kamers, objecten, samenvoegen)"], ["Allan", "Puzzels, startpagina, overig"], ["Rick", "Plaatjes opgezocht en bewerkt, verhaal"], ["Johnty", "Puzzel 2 gemaakt"], ["Ruben", "Start- en creditspagina, inventarissysteem"], ["Rishi", "Ordebewaker en tevens toezichthouder"]];
const creditsEl = document.querySelector(".credits_roll");


function showCredits(index) {
    setTimeout(function() {
        if(index < creditsList.length) {
            creditsEl.innerText = creditsList[index][0] + " | " + creditsList[index][1];
            showCredits(index + 1);
        } else {
            creditsEl.innerText = "";
            creditsList.forEach(function(el, ind) {
                if(ind > 0) creditsEl.innerText += "\n";
                creditsEl.innerText += el[0];
            });
        }
    }, (index<=0)?0:2000);
}

showCredits(0);