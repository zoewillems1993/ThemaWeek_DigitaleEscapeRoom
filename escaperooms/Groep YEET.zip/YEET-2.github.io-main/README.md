# escape-room
*NOTE :* voor deze project is het belangrijk dat je nodejs versie 16 op je computer hebt, want we hebben gebruik gemaakt van sommige js libraries die nodejs vereisen om te runnen.
Nadar je nodjs hebt geinstalleerd run de volgende command in een nieuwe terminal npm run dev.
Daarna krijg je een localhost te zien, als je die host bezoekt via je broweser, zie je de project.
het kan zijn dat je hier en daar een glitch tegenkomt, en dat is door tijd tekort, excuses daarvoor namens mijn team.
